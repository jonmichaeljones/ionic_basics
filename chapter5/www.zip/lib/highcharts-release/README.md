This is the official shim repo for Highcharts JS releases including minified files. It is optimized for inclusion by Bower.

For the Highcharts source code, issue tracker and support utilities, see [the highcharts.com repo](https://github.com/highslide-software/highcharts.com).
